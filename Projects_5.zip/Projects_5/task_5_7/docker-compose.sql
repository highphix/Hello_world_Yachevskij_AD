DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS prices;
DROP TABLE IF EXISTS products;

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50)
);

CREATE TABLE prices (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    price NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE suppliers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    product_id INTEGER REFERENCES products(id)
);

INSERT INTO products (name, category) VALUES
('Планшет', 'Электроника'),
('Сотовый телефон', 'Электроника'),
('Беспроводные наушники', 'Аксессуары'),
('ЖК-монитор', 'Электроника'),
('Механическая клавиатура', 'Аксессуары');

INSERT INTO prices (product_id, price) VALUES
(1, 54500.00),
(2, 35900.00),
(3, 2450.00),
(4, 17900.00),
(5, 1180.00);

INSERT INTO suppliers (name, product_id) VALUES
('ООО ТехноИмпорт', 1),
('ИП Электро', 1),
('ООО ТехноИмпорт', 2),
('ООО АксессуарыПлюс', 3),
('ООО ТехноИмпорт', 4),
('ИП Электро', 5);

SELECT * FROM products;
SELECT * FROM prices;
SELECT * FROM suppliers;