SELECT product_id, COUNT(*) AS suppliers_count
FROM suppliers
GROUP BY product_id
-- ORDER BY product_id ASC;